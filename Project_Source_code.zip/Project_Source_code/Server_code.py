from flask import Flask, render_template, request, jsonify, redirect, url_for
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'

DATABASE = 'database.db'

def init_db():
    if not os.path.exists(DATABASE):
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        # Create users table
        cursor.execute('''
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                username TEXT NOT NULL UNIQUE,
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            );
        ''')

        # Create tasks table
        cursor.execute('''
            CREATE TABLE tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL,
                task_name TEXT NOT NULL,
                task_description TEXT,
                priority TEXT
            );
        ''')

        # Create projects table
        cursor.execute('''
            CREATE TABLE projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id TEXT NOT NULL,
                project_name TEXT NOT NULL,
                project_description TEXT,
                start_date TEXT,
                end_date TEXT
            );
        ''')

        conn.commit()
        conn.close()

@app.route('/')
def home():
    return render_template('Frontend.html')

@app.route('/login', methods=['POST'])
def login():
    try:
        username = request.form['user']
        password = request.form['pass']

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            # Login successful
            return jsonify({'message': 'Login successful'}), 200
        else:
            # Login failed
            return jsonify({'message': 'Invalid credentials'}), 401
    except Exception as e:
        return jsonify({'message': f'Login failed: {str(e)}'}), 500

@app.route('/register', methods=['POST'])
def register():
    try:
        first_name = request.form['firstname']
        last_name = request.form['lastname']
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO users (first_name, last_name, username, email, password)
            VALUES (?, ?, ?, ?, ?)
        ''', (first_name, last_name, username, email, password))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Registration successful'}), 200
    except Exception as e:
        return jsonify({'message': f'Registration failed: {str(e)}'}), 500


@app.route('/create_project', methods=['POST'])
def create_project():
    try:
        project_id = request.form['pid']
        project_name = request.form['pname']
        project_description = request.form['pdescription']
        start_date = request.form['std']
        end_date = request.form['edt']

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO projects (project_id, project_name, project_description, start_date, end_date)
            VALUES (?, ?, ?, ?, ?)
        ''', (project_id, project_name, project_description, start_date, end_date))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Project created successfully'}), 200
    except Exception as e:
        return jsonify({'message': f'Project creation failed: {str(e)}'}), 500

@app.route('/create_task', methods=['POST'])
def create_task():
    try:
        task_id = request.form['tid']
        task_name = request.form['tname']
        task_description = request.form['tdes']
        priority = request.form['priority']

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO tasks (task_id, task_name, task_description, priority)
            VALUES (?, ?, ?, ?)
        ''', (task_id, task_name, task_description, priority))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Task created successfully'}), 200
    except Exception as e:
        return jsonify({'message': f'Task creation failed: {str(e)}'}), 500


@app.route('/check_task', methods=['POST'])
def check_task():
    try:
        task_id = request.form['taskID']

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        # Check if taskID is present in the task table
        cursor.execute('SELECT COUNT(*) FROM tasks WHERE task_id = ?', (task_id,))
        count = cursor.fetchone()[0]

        conn.close()

        if count > 0:
            # Task ID is present
            return '', 200
        else:
            # Task ID not present
            return '', 404
    except Exception as e:
        return jsonify({'message': f'Error checking task: {str(e)}'}), 500


@app.route('/check_project', methods=['POST'])
def check_project():
    try:
        project_id = request.form['projectID']

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        # Check if projectID is present in the project table
        cursor.execute('SELECT COUNT(*) FROM projects WHERE project_id = ?', (project_id,))
        count = cursor.fetchone()[0]

        conn.close()

        if count > 0:
            # Project ID is present
            return '', 200
        else:
            # Project ID not present
            return '', 404
    except Exception as e:
        return jsonify({'message': f'Error checking project: {str(e)}'}), 500


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
