Step 1: Download the ZIP folder onto your PC and proceed to unzip its contents.

Step 2: Navigate to the unzipped folder, right-click inside it, and select "Open Command Prompt" (CMD). This action will set the current folder path in the CMD.

Step 3: Initiate the server by entering the following command:
python Server_code.py

Executing this command will start the server and provide a localhost link. Open this link by pressing Ctrl and clicking on it; this action will launch the application in your default web browser.